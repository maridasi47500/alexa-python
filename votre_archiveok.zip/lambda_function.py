import json


def lambda_handler(event, context):
    # TODO implement
    print(event)
    try:
      myexpr = event["request"]["type"]
      print(myexpr)
      match myexpr:
        case "LaunchRequest":
          speak = "Salut toi ! Bienvenue! discutons."
        case _:
          myotherexpr = event["request"]["intent"]["name"]
          match myotherexpr:
            case "AMAZON.StopIntent":
                  speak = "ok ! si tu dois partir maintenant, à bientôt!"
            case: "AMAZON.HelpIntent":
                  speak="parlons d'emploi, de travail ou de ce que tu veux !!"
            case "AMAZON.CancelIntent":
                  speak="ok"
            case "garde_a_vous":
                  speak="<audio src=''/>"
                  speak="<audio src='s3://armymusic/Le Garde à vous.mp4'/>"
            case "ouvrez_le_banc":
                  speak="<audio src='s3://armymusic/Le Ban..mp3'/>"
            case "au_drapeau":
                  speak="<audio src='s3://armymusic/Musique Militaire - Sonnerie au drapeau Française.mp3'/>"
            case "entre_terre_et_mer":
                speak="<audio src='s3://armymusic/Entre Terre et Mer - Fanfare et Bagad de la 9e BIMa (CD 2017).mp3'/>"
    except:
      speak="Désolée , il y a eu une erreur "+e.message
    return {
  "version": "1.0",
  "response": {
    "outputSpeech": {
      "type": "SSML",
      "ssml": "<speak>"+speak+"</speak>"
    },
    "reprompt": {
      "outputSpeech": {
        "type": "SSML",
        "ssml": "<speak>J'ai pas compris, comment ?</speak>"
      }
    },
    "shouldEndSession": false
  },
  "userAgent": "ask-node/2.3.0 Node/v8.10.0",
  "sessionAttributes": {}
  }

